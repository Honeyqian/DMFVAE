from . import edges
from .node2vec import Node2Vec
from importlib import metadata

__version__ = metadata.version('node2vec')