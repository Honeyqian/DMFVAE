import numpy as np
import networkx as nx
from node2vec import Node2Vec
import pdb

def read_graph(filename, weighted=False):  ##输入的是边的索引
    print("Loading training graph for learning embedding...")
    edgelist = np.loadtxt(filename, dtype='float')
    if weighted:
        edgelist = [(int(edgelist[idx, 0]), int(edgelist[idx, 1])) for idx in range(edgelist.shape[0]) if
                    edgelist[idx, 2] > 0]
    else:
        edgelist = [(int(edgelist[idx, 0]), int(edgelist[idx, 1])) for idx in
                    range(edgelist.shape[0])]  ##矩阵的行数,将边的索引改为int型
        ##print("yes ok")  ##是这个
    G = nx.from_edgelist(edgelist)  ##  根据边的信息构建图graph

    # node_list = list(G.nodes)  ##G.nodes  图G涉及的点
    # adj = nx.adjacency_matrix(G, nodelist=node_list)  ##根据边绘制邻接矩阵https://blog.csdn.net/yingluo54/article/details/113325108
    # print("Graph Loaded...")
    # return (adj, node_list)
    return G

# 疾病——RNA关联矩阵

#dis_rna_matrix = np.loadtxt("data/data_miRNA_interaction_WKNKN20888.txt", delimiter='\t', skiprows=1,
# dis_rna_matrix = np.loadtxt("data/5430/association.txt")
dis_rna_matrix = np.loadtxt("data/5430/disease_miRNA_interaction.txt")
# dis_rna_matrix = np.loadtxt("data/8968/new association.txt")
print("associated matrix：dis_rna_matrix.shape:", dis_rna_matrix.shape)
# print(drug_dis_matrix)
SD_matrix = np.loadtxt("data/SD.txt", delimiter='\t', skiprows=1,usecols=[i for i in range(1, 384)])
#SD_matrix = np.loadtxt("data/ID.txt")
print("simility matrix：SD_matrix.shape:",SD_matrix.shape)
SM_matrix = np.loadtxt("data/SM.txt", delimiter='\t', skiprows=1,usecols=[i for i in range(1, 496)])
#SM_matrix = np.loadtxt("data/IM.txt")
print("simility matrix：SM_matrix.shape:",SM_matrix.shape)
# 疾病数和RNA数
dis_num = dis_rna_matrix.shape[0]
rna_num = dis_rna_matrix.shape[1]
print("疾病数量：", dis_num)
print("RNA数量：", rna_num)
# 已知关联数量, 边列表
knownnum = 0
edge = []
for i in range(dis_num):
    for j in range(rna_num):
        if dis_rna_matrix[i][j] == 1:
            knownnum = knownnum + 1
print("已知的关联总数是：", knownnum)  # 关联总数为 ：12034

 #没有关联RNA的疾病的数量
a=0
for i in range(dis_num):
    if sum(dis_rna_matrix[i, :])==0:
        a = a+1
print(a)
#没有关联疾病的RNA的数量
b=0
for j in range(rna_num):
    if sum(dis_rna_matrix[:, j])==0:
        b = b+1
print(b)

#newdis = np.zeros((dis_num, dis_num))
#newrna = np.zeros((rna_num, rna_num))
#H1 = np.hstack((SD_matrix, dis_rna_matrix))  ##np.hstack():在水平方向上平铺 512*（512+71）
#print(H1.shape)
#H2 = np.hstack((dis_rna_matrix.T, SM_matrix))  ##71*（512+71）将newRAN与转置矩阵拼接
#print(H2.shape)
#H = np.vstack((H1,H2))  ##np.vstack():在竖直方向上堆叠
#H1 = np.hstack((newdis,newrna))
#H2 = np.hstack((dis_rna_matrix,dis_rna_matrix.T))
#H = np.vstack((H1,H2))
#print(H.shape)
# 边列表
edge1 = []
edge2 = []
#for i in range(H1.shape[0]):
    #for j in range(H1.shape[1]):
        #if H1[i][j] != 0:
            #edge1.append([i, j])
#for i in range(H2.shape[0]):
    #for j in range(H2.shape[1]):
        #if H2[i][j] != 0:
            #edge2.append([i, j])
for i in range(dis_num):
    for j in range(rna_num):
        if dis_rna_matrix[i][j] != 0:
            edge1.append([i, j])
for i in range(rna_num):
    for j in range(dis_num):
        if dis_rna_matrix.T[i][j] != 0:
            edge2.append([i, j])

# print("边列表：", edge)
print("边列表的长度为：", len(edge1)) # 无向图，边的总数为关联总数的两倍， 24068
print("边列表的长度为：", len(edge2))

# FILES
EMBEDDING_FILENAME1 = './embeddings1.emb'
EMBEDDING_MODEL_FILENAME1 = './embeddings1.model'
EMBEDDING_FILENAME2 = './embeddings2.emb'
EMBEDDING_MODEL_FILENAME2 = './embeddings2.model'
EMBEDDING_FILENAME3 = './embeddings3.emb'
EMBEDDING_MODEL_FILENAME3 = './embeddings3.model'
EMBEDDING_FILENAME4 = './embeddings4.emb'
EMBEDDING_MODEL_FILENAME4 = './embeddings4.model'
EMBEDDING_FILENAME5 = './embeddings5.emb'
EMBEDDING_MODEL_FILENAME5 = './embeddings5.model'
EMBEDDING_FILENAME6 = './embeddings6.emb'
EMBEDDING_MODEL_FILENAME6 = './embeddings6.model'
EMBEDDING_FILENAME7 = './embeddings7.emb'
EMBEDDING_MODEL_FILENAME7 = './embeddings7.model'
EMBEDDING_FILENAME8 = './embeddings8.emb'
EMBEDDING_MODEL_FILENAME8 = './embeddings8.model'
np.savetxt('edge1.txt', edge1)  #
np.savetxt('edge2.txt', edge2)  #
graph1 = read_graph('edge1.txt')#疾病
print(graph1)
graph2 = read_graph('edge2.txt')
print(graph2)

node2vec = Node2Vec(graph2, dimensions=32, walk_length=30, num_walks=200, workers=4, p=0.25,q=0.25)
#node2vec = Node2Vec(graph1, dimensions=64, walk_length=30, num_walks=200, workers=4)
## if d_graph is big enough to fit in the memory, pass temp_folder which has enough disk space
# Note: It will trigger "sharedmem" in Parallel, which will be slow on smaller graphs
#node2vec = Node2Vec(graph, dimensions=64, walk_length=30, num_walks=200, workers=4, temp_folder="/mnt/tmp_data")

# Embed生成节点嵌入
model = node2vec.fit(window=10, min_count=1, batch_words=4,)  # Any keywords acceptable by gensim.Word2Vec can be passed, `dimensions` and `workers` are automatically passed (from the Node2Vec constructor)
# Look for most similar nodes
model.wv.most_similar('2')  # Output node names are always strings

# Save embeddings for later usea
model.wv.save_word2vec_format(EMBEDDING_FILENAME2)
# Save model for later use
model.save(EMBEDDING_MODEL_FILENAME2)
