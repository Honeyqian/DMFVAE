# coding: utf-8

# 卷积核 1*20 池化层窗口1*10
# 正负样本各20888
# sigmoid激活函数 2个神经元


# 3个卷积层 3个池化层 batchsize是512，dropout是0.7，一个epoch的时间从300s减少至46s左右
from turtle import pos
from unittest import result
import warnings

import keras
import scipy
from keras.layers import Lambda
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from tensorflow.python.keras import optimizers
from xgboost import XGBClassifier

warnings.filterwarnings('ignore')
import time
import os
import numpy as np
import pandas as pd
import random
import shutil
from math import floor
# import keras
from keras.models import Model
from keras import models, layers, Sequential
from keras import backend as K
from keras.utils import to_categorical  # 独热编码
from keras.callbacks import EarlyStopping, ReduceLROnPlateau, CSVLogger, ModelCheckpoint  # 回调函数

from sklearn.model_selection import KFold
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelBinarizer  # 标签 二值化
from sklearn.metrics import roc_curve, auc, precision_score, classification_report, precision_recall_curve
from scipy import interp

from scipy import io

import matplotlib.pyplot as plt


# In[2]:


# 1.读取数据
def read_data(path_positive, path_negative):
    positive = np.load(path_positive)
    negative = np.load(path_negative)
    return positive, negative


# npz 数据转换为 list
def npz2list(path):
    # 保存列表
    # numpy.savez('list1',list_in)
    list1 = np.load(path, allow_pickle=True)
    # print(list1.files) # 查看各个数组名称
    arr_0 = list1['arr_0']  # object 只读
    list_o = []
    for i in arr_0:
        list_o.append(i)
    return list_o


# 获得positive_data, negative_data 的坐标（position)
def get_position(path_MD):
    data_MD = pd.read_excel(path_MD, index_col=0)  # miRNA和疾病 关联信息   （383，495）

    print("get_positionz中的data_MD")
    data_MD5 = np.array(data_MD)
    print(data_MD5.shape)
    # positive
    positive_1 = []

    # negative
    positive_0 = []

    for i in range(383):  # 383
        for j in range(495):  # 495
            label = data_MD.iloc[i][j]  # 0 or 1
            if (label == 1):  # positive
                positive_1.append((i, j))  # 元组
            else:  # negative
                positive_0.append((i, j))  # 元组
    return positive_1, positive_0


def transform_data(train_data):
    """
    train_data的结构：[(matrix_cell,label,(position))]
    return :
        trainX, labelY, position
    """
    feature = []  # 特征
    label_ = []  # 标签
    position = []  # 坐标
    for i in range(len(train_data)):
        feature.append(train_data[i][0])
        label_.append(train_data[i][1])
        position.append(train_data[i][2])

    feature = np.array(feature)
    label_ = np.array(label_)

    dataX = feature[:, :,:,  np.newaxis]  # (19256, 2, 878, 1)
    # dataX = feature[:, :, np.newaxis]  # (19256, 2, 878, 1)
    #dataX = feature[2, np.newaxis]

    # 对标签 独热编码
    lb = LabelBinarizer()
    labelY = lb.fit_transform(label_)  # 标签二值化
    labelY = to_categorical(labelY)  # 二值化标签 转换成 独热编码

    return dataX, labelY, position




def Create_VAE(num, x_train):
    y_train = np.squeeze(x_train)
    encoding_dim = 128
    input_img = layers.Input(shape=(1, num, 1))
    # 建立神经网络
    # 编码层
    encoded_input = layers.Flatten()(input_img)
    encoded = layers.Dense(256, activation='relu')(encoded_input)

    #encoded = layers.Dense(128, activation='relu')(encoded)
    #encoded = layers.Dense(100, activation='relu')(encoded)
    #miRNA_encoder_output = layers.Dense(encoding_dim)(encoded)
    z_mean = layers.Dense(encoding_dim)(encoded)
    z_log_var = layers.Dense(encoding_dim)(encoded)

    # 重参数技巧
    def sampling(args):
        z_mean, z_log_var = args
        epsilon = K.random_normal(shape=K.shape(z_mean))
        return z_mean + K.exp(z_log_var / 2) * epsilon

    # 重参数层，相当于给输入加入噪声
    z = Lambda(sampling, output_shape=(encoding_dim,))([z_mean, z_log_var])
    # 解码层
    #decoded = layers.Dense(100, activation='relu')(miRNA_encoder_output)
    #decoded = layers.Dense(128, activation='relu')(miRNA_encoder_output)

    #decoded = layers.Dense(128, activation='relu')(z)
    decoded = layers.Dense(256, activation='relu')(z)
    decoded_output = layers.Dense(num, activation='sigmoid')(decoded)
    # 构建自编码模型
    vae = models.Model(input=input_img, output=decoded_output)
    xent_loss = K.sum(K.binary_crossentropy(encoded_input, decoded_output), axis=-1)
    #KLS
    kl_loss = - 0.5 * K.sum(1 + z_log_var - K.square(z_mean) - K.exp(z_log_var), axis=-1)
    vae_loss = K.mean(xent_loss + kl_loss)
    vae.add_loss(vae_loss)
    vae.compile(optimizer='adam')#'rmsprop'
    vae.summary()
    vae.fit(x_train,batch_size=512, epochs=900, shuffle=True)
    #解码器部分
    encoder = models.Model(input=input_img, output=z_mean)

    # 激活模型
    #autoencoder.compile(optimizer='adam', loss='mse')
    #print(autoencoder.summary())
    # autoencoder.fit(x_train, x_train, epochs=20, batch_size=100, shuffle=True)
    # return autoencoder, encoder
    #vae.fit(x_train, y_train, batch_size=100, epochs=1,shuffle=True)
    return encoder
    # miRNA_encoded_imgs = encoder.predict(x_train)
    # return miRNA_encoder_output, miRNA_encoded_imgs
# In[5]:
def channel_attention(inputs, ratio=12):
    '''ratio代表第一个全连接层下降通道数的倍数'''

    channel = int(inputs.shape[-1])  # 获取输入特征图的通道数
    #channel = 192*2
    print('channel :', channel)
    # 分别对输出特征图进行全局最大池化和全局平均池化
    # [h,w,c]==>[None,c]
    x_max = layers.GlobalMaxPooling2D()(inputs)
    x_avg = layers.GlobalAveragePooling2D()(inputs)
    print('xmax', x_max)
    print('x_avg', x_avg)
    # [None,c]==>[1,1,c]
    x_max = layers.Reshape([1, 1, channel])(x_max)  # -1代表自动寻找通道维度的大小
    print('x_mnax:',x_max)
    x_avg = layers.Reshape([1, 1, channel])(x_avg)  # 也可以用变量channel代替-1
    # 第一个全连接层通道数下降1/4, [1,1,c]==>[1,1,c//4]
    print('x_max',x_max)
    print('channel*ratio',channel*ratio)
    x_max = layers.Dense((int)(channel * ratio))(x_max)
    x_avg = layers.Dense((int)(channel * ratio))(x_avg)
    # relu激活函数
    x_max = layers.Activation('relu')(x_max)
    x_avg = layers.Activation('relu')(x_avg)
    # 第二个全连接层上升通道数, [1,1,c//4]==>[1,1,c]
    x_max = layers.Dense(channel)(x_max)
    x_avg = layers.Dense(channel)(x_avg)
    # 结果在相叠加 [1,1,c]+[1,1,c]==>[1,1,c]
    x = layers.Add()([x_max, x_avg])
    # 经过sigmoid归一化权重
    x = layers.Activation('sigmoid')(x)
    # 输入特征图和权重向量相乘，给每个通道赋予权重
    x = layers.Multiply()([inputs, x])  # [h,w,c]*[1,1,c]==>[h,w,c]
    return x
def create_model():
    # 搭建网络 ,无正则化
    inputs_image = keras.layers.Input(shape=(2,160,1))
    print(inputs_image.shape)
    # x = channel_attention(inputs_image)
    #x = keras.layers.Conv2D(16,(1,4),border_mode='same',activation="relu")
    # x = CBAM_attention(inputs_image)
    x = keras.layers.Conv2D(32, (1, 2), padding='same', activation="relu")(inputs_image)
    #x = keras.layers.Conv2D(64, (1, 2), padding='same', strides=2, activation="relu")(x)
    #x = keras.layers.BatchNormalization()(x)
    x = channel_attention(x)
    x = keras.layers.MaxPooling2D((1, 2), padding='same')(x)
    #x = CBAM_attention(x)
    x = keras.layers.Flatten()(x)
    x = keras.layers.Dropout(0.5)(x)
    x = keras.layers.Dense(64,activation="relu")(x)
    x = keras.layers.Dense(2,activation="softmax")(x)
    model= models.Model(input=inputs_image, output=x)
    model.compile(optimizer='adam',
                  loss="binary_crossentropy",
                  metrics=["acc"])
    return model

# 3. 创建模型
# def create_model():
#     # 搭建网络 ,无正则化
#     model = models.Sequential()
#     model.add(layers.Conv2D(32, (1, 5), border_mode='same', activation="relu", input_shape=(2,64, 1)))
#     model.add(layers.MaxPooling2D((1, 2), padding='same'))
#
#     model.add(layers.Conv2D(64, (1, 5), border_mode='same', activation="relu"))
#     model.add(layers.MaxPooling2D((1, 2), padding='same'))
#     # model.add(layers.Dropout(0.2))
#     # model.add(layers.Conv2D(128,(1,20),border_mode='same',activation="relu"))
#     # model.add(layers.MaxPooling2D((1, 10), padding='same'))
#     # model.add(layers.Dropout(0.25))
#     model.add(layers.Flatten())
#     model.add(layers.Dropout(0.5))
#     model.add(layers.Dense(64, activation="relu"))
#     # model.add(layers.Dropout(0.5))
#     model.add(layers.Dense(2, activation="softmax"))
#
#     # 配置优化设置
#     model.compile(optimizer='adam',
#                   loss="binary_crossentropy",
#                   metrics=["acc"])
#     return model


# In[4]:
def getsample(pathD, pathM, pathSD,pathSM, pathData,pathResult):
    representationD = np.loadtxt(pathD)  # 383*495
    print(representationD.shape)
    representationM = np.loadtxt(pathM)  # 495*383
    print(representationM.shape)
    SD = np.loadtxt(pathSD)
    SM = np.loadtxt(pathSM)
    # SM = SM.T
    # ID = np.loadtxt(pathID)
    # IM = np.loadtxt(pathIM)

     # 将标签转为189585行1列
    matrix_cells_1 = []  # positive
    labels_1 = []
    matrix_cells_01 = []
    matrix_cells_02 = []
    matrix_cells_0 = []  # negative
    labels_0 = []
    for i in range(representationD.shape[0]):  # 383
        for j in range(representationM.shape[0]):  # 495
            # label = data_MD.iloc[i][j]   # 0 or 1
            label = data_MD1[i][j]  # 0 or 1
            if (label == 1):  # positive
                #sample1 = np.concatenate((ID[i], representationD[i]))
                #sample2 = np.concatenate((IM[j], representationM[j]))
                #matrix_cell_1 = np.concatenate((sample1, sample2))
                # mc_1 = np.array(representationD[i])
                # mc_2 = np.array(representationM[j])
                mc_1 = np.hstack((SD[i], representationD[i]))
                mc_2 = np.hstack((SM[j], representationM[j]))
                matrix_cell_1 = np.vstack((mc_1, mc_2))
                # matrix_cells_12 = np.vstack((mc_3,mc_4))
                #matrix_cell_1 = np.hstack((mc_1,mc_2))  # (2,878) , numpy.ndarray
                # matrix_cell_1 = matrix_cell_1[:,:,np.newaxis]
                matrix_cells_1.append(matrix_cell_1)  # matrix_cell_1   (2,878)
                labels_1.append(label)
            else:  # negative
                #sample1 = np.concatenate((ID[i],representationD[i]))
                #sample2 = np.concatenate((IM[j], representationM[j]))
                #matrix_cell_0 = np.concatenate((sample1,sample2))
                # mc_1 = np.array(representationD[i])
                # mc_2 = np.array(representationM[j])
                mc_1 = np.hstack((SD[i], representationD[i]))
                mc_2 = np.hstack((SM[j], representationM[j]))
                #mc_3 = np.hstack((DE383[i], DE495[i]))
                #mc_4 = np.hstack((ME495[j], ME383[j]))
                # mc_3 = np.hstack((DE [i], NEWSD451 [i]))
                # mc_4 = np.hstack((ME [j], NEWSM451 [j]))
                #matrix_cells_01 = np.vstack((mc_1, mc_2))
                # matrix_cells_02 = np.vstack((mc_3, mc_4))

                matrix_cell_0 = np.vstack((mc_1, mc_2))  # (2,878) , numpy.ndarray
                # matrix_cell_0 = matrix_cell_0[:,:,np.newaxis]  # (2, 878)
                matrix_cells_0.append(matrix_cell_0)
                labels_0.append(label)

    # 类型转换 list -> numpy.ndarray
    #     print("开始类型转换 list -> numpy.ndarray")
    matrix_cells_1 = np.array(matrix_cells_1)  # (12034, 2, 878)

    # matrix_cells_1 = matrix_cells_1[:,np.newaxis,:]#将二维数组变成三维
    labels_1 = np.array(labels_1)  # (12034,)
    #     print("转换成array后matrix_cells_1的shape")
    print(matrix_cells_1.shape)
    matrix_cells_0 = np.array(matrix_cells_0)  # (177551, 2, 878)
    # matrix_cells_0 = matrix_cells_0[:,np.newaxis,:]#将二维数组变成三维
    labels_0 = np.array(labels_0)  # (177551,)
    #     print("转换成array后matrix_cells_0的shape")
    print(matrix_cells_0.shape)
    # 存储数据
    #     print("开始存储数据 matrix_cells_positive451.npz")
    np.savez(pathResult + "matrix_cells_positive_mfcnn.npz", matrix_cell=matrix_cells_1,
             label=labels_1)
    np.savez(pathResult + "matrix_cells_negative_mfcnn.npz", matrix_cell=matrix_cells_0,
             label=labels_0)

    path_mRNA_Disease = pathData + "5430/disease_miRNA.xlsx"  # mRNA-疾病 关联文件
    #path_mRNA_Disease = pathData + "12034/disease_miRNA_interaction.xlsx"
    # 1. 读入数据
    positive_data = np.load(pathResult + "matrix_cells_positive_mfcnn.npz")
    negative_data = np.load(pathResult + "matrix_cells_negative_mfcnn.npz")

    # 1.1 获得positive_data, negative_data 的坐标（position)
    positive_position, negative_position = get_position(path_mRNA_Disease)

    # 1.2 将数据与 坐标 绑在一起
    positive_data_position = list(zip(positive_data['matrix_cell'], positive_data['label'], positive_position))
    negative_data_position = list(zip(negative_data['matrix_cell'], negative_data['label'], negative_position))

    return positive_data_position, negative_data_position, negative_data

def calculate_performace(test_num, pred_y, labels):#计算性能
    tp = 0
    fp = 0
    tn = 0
    fn = 0
    for index in range(test_num):
        if labels[index] == 1:
            if labels[index] == pred_y[index]:
                tp = tp + 1
            else:
                fn = fn + 1
        else:
            if labels[index] == pred_y[index]:
                tn = tn + 1
            else:
                fp = fp + 1
    acc = float(tp + tn) / test_num

    if tp == 0 and fp == 0:
        precision = 0
        MCC = 0
        f1_score = 0
        sensitivity = float(tp) / (tp + fn)
        specificity = float(tn) / (tn + fp)
    else:
        precision = float(tp) / (tp + fp)
        sensitivity = float(tp) / (tp + fn)
        specificity = float(tn) / (tn + fp)
        MCC = float(tp * tn - fp * fn) / (np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)))
        f1_score = float(2 * tp) / ((2 * tp) + fp + fn)
    return acc, precision, sensitivity, specificity, MCC, f1_score
def transfer_label_from_prob(proba):#判断标签为0或者1
    label = [1 if val >= 0.5 else 0 for val in proba]
    return label
def calculate_auc(labelY, predict):
    label = np.array([np.argmax(y) for y in labelY])

    score = np.array(predict)
    score = score[..., 1]
    print(label.shape)
    print(score.shape)
    fpr, tpr, thresholds = roc_curve(label, score)
    roc_auc = auc(fpr, tpr)

    return fpr, tpr, roc_auc


# In[5]:


# 获取训练行/列向量的样本 raw representation
# pathD = "E:\\jupyter\\CNN\\5CV\\result\\latent_representationD.txt"
# pathM = "E:\\jupyter\\CNN\\5CV\\result\\latent_representationM.txt"
# pathSD = "E:\\jupyter\\CNN\\5CV\\data\\NEWSD451.txt"
# pathSM = "E:\\jupyter\\CNN\\5CV\\data\\NEWSM451.txt"
# pathData ="E:\\jupyter\\CNN\\5CV\\data\\"
# pathResult = "E:\\jupyter\\CNN\\5CV\\result\\"
pathD = "result/latent_representationD.txt"
pathM = "result/latent_representationM.txt"
# pathSD = "data/8968/dd32.txt"
# pathSM = "data/8968/mm32.txt"
pathSD = "data/5430/disease 1.txt"
pathSM = "data/5430/miRNA 1.txt"
# pathSD = "data/12034/dd64.txt"
# pathSM = "data/12034/mm64.txt"
#pathde = "data/D_GSM.txt"
#pathme = "data/M_GSM.txt"

pathData = "data/"
pathResult = "result/"

NN_enable = True
# In[11]:


# 导入正负样本，并将其格式转换为list
XD_matrixcell_positive = npz2list(pathData + "5430/XD_post.npz")
XD_matrixcell_negative = npz2list(pathData + "5430/XD_neg.npz")

XM_matrixcell_positive = npz2list(pathData + "5430/XM_post.npz")
XM_matrixcell_negative = npz2list(pathData + "5430/XM_neg.npz")
# XD_matrixcell_positive = npz2list(pathData + "8968/XD_post.npz")
# XD_matrixcell_negative = npz2list(pathData + "8968/XD_neg.npz")
#
# XM_matrixcell_positive = npz2list(pathData + "8968/XM_post.npz")
# XM_matrixcell_negative = npz2list(pathData + "8968/XM_neg.npz")
#XD_matrixcell_positive = npz2list(pathData + "12034/XD_matrixcell_positive2.npz")
#XD_matrixcell_negative = npz2list(pathData + "12034/XD_matrixcell_negative2.npz")
#XM_matrixcell_positive = npz2list(pathData + "12034/XM_matrixcell_positive2.npz")
#XM_matrixcell_negative = npz2list(pathData + "12034/XM_matrixcell_negative2.npz")

# In[38]:


# In[6]:

data_MD = pd.read_excel(pathData + "5430/disease_miRNA.xlsx")
# data_MD = pd.read_excel(pathData + "8968/association.xlsx")
data_DM = pd.read_excel(pathData + "12034/newmd.xlsx",index_col=0)
data_MD0 = np.array(data_MD)
data_DM0 = np.array(data_DM)
data_MD1 = data_MD0

# data_MD1 = np.delete(data_MD0,0, axis=1)
print("data_MD1.shape:")
print(data_MD1.shape)
ID = np.loadtxt(pathSD)
IM = np.loadtxt(pathSM)

print(ID.shape)
print(IM.shape)
# print(DE.shape)
# print(ME.shape)

# In[7]:
# 分别打乱顺序
random.shuffle(XD_matrixcell_positive)
random.shuffle(XD_matrixcell_negative)
random.shuffle(XM_matrixcell_positive)
random.shuffle(XM_matrixcell_negative)

# 组合数据
# 选取12034个负样本，并与12034个正样本相组合，得到训练样本 alldata
alldataD = XD_matrixcell_positive + XD_matrixcell_negative[0:5430]# 24068个(matrix cell,label,（坐标）)
alldataM = XM_matrixcell_positive + XM_matrixcell_negative[0:5430]# 24068个(matrix cell,label,（坐标）)
# alldataD = XD_matrixcell_positive + XD_matrixcell_negative[0:8968]# 24068个(matrix cell,label,（坐标）)
# alldataM = XM_matrixcell_positive + XM_matrixcell_negative[0:8968]# 24068个(matrix cell,label,（坐标）)
# alldataD = XD_matrixcell_positive + XD_matrixcell_negative# 24068个(matrix cell,label,（坐标）)
# alldataM = XM_matrixcell_positive + XM_matrixcell_negative
# 打乱组合后的数据
random.shuffle(alldataD)
random.shuffle(alldataM)

# 构建 dataX(array)(41776, 2, 878, 1), labelY (array)(41776, 2),position(list) 41776
dataXD, labelYD, position = transform_data(alldataD)
dataXM, labelYM, position = transform_data(alldataM)
# In[8]:
labelYD.shape
# dataXD = np.array(dataXD)
# dataXM = np.array(dataXM)
# dataXM = np.squeeze(dataXM)
# dataXD = dataXD[:,np.newaxis,:,:]
# dataXM = dataXM[:,np.newaxis,:,np.newaxis]
print(dataXD.shape)
print(dataXM.shape)
# dataXM = dataXM[:,np.newaxis,:,:]
# In[10]:


# dataXD, labelYD, predictXD, predictYD, predict_positionD = split_data(XD_matrixcell_positive,XD_matrixcell_negative,fold)
# dataXM, labelYM, predictXM, predictYM, predict_positionM = split_data(XM_matrixcell_positive,XM_matrixcell_negative,fold)
# 划分数据集
print("开始划分数据集")
# trainXD(33420, 1, 495, 1); testXD(8356, 1, 495, 1); trainYD(33420,2); testYD(8356,2)
(trainXD, testXD, trainYD, testYD) = train_test_split(dataXD, labelYD, test_size=0.2, random_state=1, shuffle=True)
(trainXM, testXM, trainYM, testYM) = train_test_split(dataXM, labelYM, test_size=0.2, random_state=1, shuffle=True)

print(trainXD.shape)
print(testXD.shape)
print(trainYD.shape)


precision_scores = []
tprs = []
aucs = []
t = 0
mean_tpr = 0.0

mean_fpr = np.linspace(0, 1, 100)
all_performance = []
for wqq in range(1):
    print("开始创建模型")
    # 创建处理 raw presentation 的模型
    encoder_D = Create_VAE(495, trainXD)
    encoder_M = Create_VAE(383, trainXM)
    # encoder_D = Create_VAE(788, trainXD)
    # encoder_M = Create_VAE(374, trainXM)

    # 得到latent representation--------------------------------------------------------------------
    # 预测并得到latent representation---------------------------------------------------------------------
    latent_representationD = []  # 383*495
    latent_representationM = []  # 495*383
    for k in range(383):
        xD = data_MD1[k][np.newaxis, np.newaxis, :, np.newaxis]
        latent_repreD = encoder_D.predict(xD)  # 1*128'
        if (k == 0):
            latent_representationD = latent_repreD
        else:
            latent_representationD = np.vstack((latent_representationD, latent_repreD))
    for k in range(495):
        xM = data_MD1.T[k][np.newaxis, np.newaxis, :, np.newaxis]
        latent_repreM = encoder_M.predict(xM)  # 1*128
        if (k == 0):
            latent_representationM = latent_repreM
        else:
            latent_representationM = np.vstack((latent_representationM, latent_repreM))
    np.savetxt(pathD, latent_representationD, fmt='%.5f')  # 383 * 495
    np.savetxt(pathM, latent_representationM, fmt='%.5f')  # 495 * 383
    # 将latent representation、SD、SM整合成matrix cell------------------------------------------------------------

    positive_data_position, negative_data_position, negative_data = getsample(pathD, pathM, pathSD, pathSM, pathData, pathResult)

    # 分别打乱顺序
    random.shuffle(positive_data_position)
    random.shuffle(negative_data_position)

    # 组合数据
    # 选取12034个负样本，并与12034个正样本相组合，得到训练样本 alldata
    alldata = positive_data_position + negative_data_position[0:5430] # 20888*2(matrix cell,label,（坐标）)
    # alldata = positive_data_position + negative_data_position[0:8968] # 20888*2(matrix cell,label,（坐标）)

    # 打乱组合后的数据
    random.shuffle(alldata)
    postivate_data = positive_data_position
    # dataX, labelY, position = transform_data(postivate_data)
    # 构建 dataX(array)(24068, 2, 878, 1), labelY (array)(24068, 2),position(list) 24068
    dataX, labelY, position = transform_data(alldata)
    # dataX = np.squeeze(dataX)
    # # dataX = np.array(dataX)
    # dataX = dataX[:,:,:,np.newaxis]

    # 划分训练集 测试集--------------------------------------------------------------------------------
    # (trainX, testX, trainY, testY) = train_test_split(dataX, labelY, test_size=0.2, random_state=1, shuffle=True)
    # print("dataX labelY trainX testX trainY testY的大小")
    # print(dataX.shape)
    # print(labelY.shape)
    # print(trainX.shape)
    # print(testX.shape)
    # print(trainY.shape)
    # print(testY.shape)
    # 划分为5份----------------------------------------------------------------------------------------
    # dataX, labelY, predictX, predictY, predict_position = split_data(positive_data_position,negative_data_position,fold)
    print("positive_data_position和negative_data_position的长度 ")
    print(len(positive_data_position))
    print(len(negative_data_position))

    #         # 创建模型-----------------------------------------------------------------------------------------
    model = create_model()

    # 增加回调函数
    logTime = time.strftime("%Y-%m-%d-%H%M%S", time.localtime())  # 运行程序的时间
    log_file_path = 'log\\log_' + logTime + '.csv'  # 实验日志的路径
    trained_models_path = 'trained_models\\'  # 实验模型的路径
    if (os.path.exists(trained_models_path) != 1):
        os.mkdir(trained_models_path)

    # model callbacks
    patience = 5  # 如果验证精度在 patience 轮内没有改善，就触发回调函数。
    early_stop = EarlyStopping('val_acc', 0.01, patience=patience)  # val_acc 在 patience 轮内没有提升0.01，就会触发 早停机制
    reduce_lr = ReduceLROnPlateau('val_acc', factor=0.1, patience=int(patience / 2), verbose=1)  # 性能没有提升时，调整学习率
    csv_logger = CSVLogger(log_file_path, append=True)  # True:追加 ; False: 覆盖
    model_names = trained_models_path + logTime + '.{epoch:02d}-{acc:2f}.h5'
    model_checkpoint = ModelCheckpoint(model_names, monitor='val_acc', mode="max", verbose=1, save_best_only=True,
                                       save_weights_only=True)

    # callbacks = [model_checkpoint,csv_logger,early_stop,reduce_lr]
    callbacks = [csv_logger, early_stop, reduce_lr]

    # 训练模型-----------------------------------------------------------------------------------------
    # history = model.fit(trainX,trainY,validation_data=(testX,testY),batch_size=512,epochs=1,callbacks=callbacks)

    # 得到预测得分--------------------------------------------------------------------------------------
    # score_1 = model.predict(predictX)# 5. 预测剩下的正样本数据
    # score_0 = model.predict(negative_data['matrix_cell'][:, :, :, np.newaxis])# 6. 预测 17W 个负样本数据

    # In[12]:
    clf1 = XGBClassifier(learning_rate=0.1, n_estimators=1000, max_depth=10)
    clf2 = RandomForestClassifier(n_estimators=100, max_depth=10)
    clf3 = SVC(C=0.1, probability=True)
    clf4 = LogisticRegression(penalty='l1',C=0.5,solver="liblinear")
    eclf = VotingClassifier(estimators=[('xgb', clf1), ('rf', clf2), ('svc', clf3),('l1', clf4)], voting='hard')

    kf = KFold(n_splits=5, random_state=0, shuffle=True)
    for train_index, test_index in kf.split(dataX, labelY):
        x_train, x_test = dataX[train_index], dataX[test_index]
        y_train, y_test = labelY[train_index], labelY[test_index]
        #y_train = y_train[...,1]
        #clf1.fit(x_train,y_train)
        model = create_model()
        model.fit(x_train, y_train, batch_size=512, epochs=100)
        y_proba = model.predict(x_test)
        y_proba = y_proba[...,1]
        y_pred = transfer_label_from_prob(y_proba)
        y_pred = np.array(y_pred)
        y_test = np.array([np.argmax(y) for y in y_test])
        # y_pred = y_pred[..., 1]
        acc, precision, sensitivity, specificity, MCC, f1_score = calculate_performace(len(y_test),y_pred,y_test)
        fpr, tpr, auc_thresholds = roc_curve(y_test, y_proba)
        tprs.append(interp(mean_fpr, fpr, tpr))
        tprs[-1][0] = 0.0
        auc_score = auc(fpr, tpr)
        scipy.io.savemat('raw_DNN', {'fpr': fpr, 'tpr': tpr, 'auc_score': auc_score})

        precision1, recall, pr_threshods = precision_recall_curve(y_test, y_proba)
        aupr_score = auc(recall, precision1)
        # print(acc, precision, sensitivity, MCC, auc_score, aupr_score, f1_score)
        # ll_performance.append([acc, precision, sensitivity, MCC, auc_score, aupr_score, f1_score])

        print(acc, precision, sensitivity, specificity, MCC, auc_score, aupr_score, f1_score)
        all_performance.append([acc, precision, sensitivity, specificity, MCC, auc_score, aupr_score, f1_score])
        # precision_scores.append(precision_score(y_test_positive, y_pred_positive))
        # interp:插值 把结果添加到tprs列表中
        # 计算auc
        t = t + 1

        plt.plot(fpr, tpr, label='ROC fold %d (AUC = %0.4f)' % (t, auc_score))
        mean_tpr += interp(mean_fpr, fpr, tpr)
        mean_tpr[0] = 0.0
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC Curves')
        plt.legend()
        roc_auc = auc(fpr, tpr)
        aucs.append(roc_auc)
#mean_tpr /= 5
#mean_tpr[-1] = 1.0
#mean_auc = auc(mean_fpr, mean_tpr)
#plt.plot(mean_fpr, mean_tpr, '--', linewidth=2.5, label='Mean ROC (AUC = %0.4f)' % mean_auc)
#print(testYD.shape)
plt.rc('font', family='Times New Roman')
plt.plot([0, 1], [0, 1], linestyle='--', lw=2, color='r',  alpha=.2)
mean_tpr = np.mean(tprs, axis=0)
mean_tpr[-1] = 1.0
mean_auc = auc(mean_fpr, mean_tpr)  # 计算平均AUC值
std_auc = np.std(aucs)
plt.plot(mean_fpr, mean_tpr, color='b', label=r'Mean ROC  (AUC = %0.4f $\pm$ %0.4f)' % (mean_auc, std_auc), lw=2, alpha=.2)
std_tpr = np.std(tprs, axis=0)
tprs_upper = np.minimum(mean_tpr + std_tpr, 1)
tprs_lower = np.maximum(mean_tpr - std_tpr, 0)
plt.fill_between(mean_fpr, tprs_lower, tprs_upper, color='grey', alpha=.2,
                 label=r'$\pm$ 1 std. dev.')
plt.xlim([-0.05, 1.05])
plt.ylim([-0.05, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('(A) The ROC Curves in the balanced dataset')
plt.legend(loc='lower right')
plt.show()
print('mean performance：')
print(np.mean(np.array(all_performance), axis=0))
Mean_Result = np.mean(np.array(all_performance), axis=0)
print('---' * 20)
print('Mean-Acc=', Mean_Result[0], '\n Mean-pre=', Mean_Result[1])
print('Mean-Sen=', Mean_Result[2], '\n Mean-Spe=', Mean_Result[3])
print('Mean-MCC=', Mean_Result[4], '\n' 'Mean-auc=', Mean_Result[5])
print('Mean-Aupr=', Mean_Result[6], '\n' 'Mean_F1=', Mean_Result[7])



# 转换成383 * 495的概率矩阵

# data_SD = pd.read_excel("E:\\jupyter\\CNN\\数据集\\disease semantic similarity1.xlsx",index_col=0)  # 疾病相似性  （383，383）
# data_MD = pd.read_excel("E:\\jupyter\\CNN\\数据集\\disease_miRNA_interaction_WKNKN20888.xlsx",index_col=0)     # miRNA和疾病 关联信息   （383，495）
# data_SM = pd.read_excel("E:\\jupyter\\CNN\\数据集\\miRNA functional similarity.xlsx",index_col=0)   # miRNA相似性（495，495）
data_SD = pd.read_excel(pathData + "disease semantic similarity1.xlsx", index_col=0)  # 疾病相似性  （383，383）
data_MD = pd.read_excel(pathData + "12034/disease_miRNA_interaction.xlsx", index_col=0)  # miRNA和疾病 关联信息   （383，495）
data_SM = pd.read_excel(pathData + "miRNA functional similarity.xlsx", index_col=0)  # miRNA相似性（495，495）

df0 = pd.DataFrame(columns=['疾病', 'mRNA', 'label', 'score'])
df1 = pd.DataFrame(columns=['疾病', 'mRNA', 'label', 'score'])

for i in range(383):  # 383
    for j in range(495):  # 495
        label = data_MD.iloc[i][j]  # 0 or 1
        if (label == 1):  # positive
            df_temp = pd.Series({'疾病': data_MD.index[i],
                                 'mRNA': data_MD.columns[j],
                                 'label': 1,
                                 'score': 0})
            df1 = df1.append(df_temp, ignore_index=True)
        else:  # negative
            df_temp = pd.Series({'疾病': data_MD.index[i],
                                 'mRNA': data_MD.columns[j],
                                 'label': 0,
                                 'score': 0})
            df0 = df0.append(df_temp, ignore_index=True)

# In[18]:


df1.to_excel('疾病_mRNA_1.xlsx', index=0)
df0.to_excel('疾病_mRNA_0.xlsx', index=0)







